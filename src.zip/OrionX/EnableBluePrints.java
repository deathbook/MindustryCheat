package OrionX;

import arc.Events;
import arc.util.Log;
import mindustry.Vars;
import mindustry.game.EventType;

public class EnableBluePrints {

    private static boolean isBlueprintsEnabled = false;

    public EnableBluePrints() {
        // 在世界加载结束时应用当前蓝图功能状态
        Events.on(EventType.WorldLoadEndEvent.class, event -> {
            enable();
        });
    }

    // 启用蓝图功能
    public static void enable() {
        isBlueprintsEnabled = true;
        Vars.state.rules.schematicsAllowed = true;
        Vars.ui.chatfrag.addMessage("[purple][OrionX][red]蓝图功能已启用");
        Log.info("[purple][OrionX][red]蓝图功能已启用");
    }

    // 禁用蓝图功能
    public static void disable() {
        isBlueprintsEnabled = false;
        Vars.state.rules.schematicsAllowed = false;
        Vars.ui.chatfrag.addMessage("[purple][OrionX][red]蓝图功能已禁用");
        Log.info("[purple][OrionX][red]蓝图功能已禁用");
    }
}
