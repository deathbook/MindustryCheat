package OrionX;

import arc.Events;
import arc.util.Log;
import mindustry.Vars;
import mindustry.game.EventType;

public class AntiFog {

    private static boolean isFogDisabled = false;

    public AntiFog() {
        // 在世界加载结束时禁用战争迷雾
        Events.on(EventType.WorldLoadEndEvent.class, event -> {
            if (isFogDisabled) {
                disable();
            }
        });
    }

    // 启用战争迷雾
    public static void enable() {
        isFogDisabled = false;
        Vars.state.rules.fog = true;
        Vars.ui.chatfrag.addMessage("[purple][OrionX][red]战争迷雾已启用");
        Log.info("[purple][OrionX][red]战争迷雾已启用");
    }

    // 禁用战争迷雾
    public static void disable() {
        isFogDisabled = true;
        Vars.state.rules.fog = false;
        Vars.ui.chatfrag.addMessage("[purple][OrionX][green]战争迷雾已禁用");
        Log.info("[purple][OrionX][green]战争迷雾已禁用");
    }
}
