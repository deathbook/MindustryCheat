package OrionX;

import arc.Events;
import mindustry.Vars;
import mindustry.game.EventType.GameOverEvent;
import mindustry.gen.Call;

public class AutoGG {
    private static boolean enabled = false;

    public static void enable() {
        if (!enabled) {
            enabled = true;
            Events.on(GameOverEvent.class, event -> {
                if (enabled) {
                    Call.sendChatMessage("GG");
                    // 这里可以调用发送聊天消息的方法
                }
            });
            System.out.println("[purple][OrionX][red]AutoGG 已启用");
            Vars.ui.chatfrag.addMessage("[purple][OrionX][red]AutoGG 已启用");
        }
    }

    public static void disable() {
        enabled = false;
        System.out.println("[purple][OrionX][red]AutoGG 已禁用");
        Vars.ui.chatfrag.addMessage("[purple][OrionX][red]AutoGG 已禁用");
    }
}
