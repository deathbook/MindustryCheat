package OrionX;

import arc.util.Log;
import mindustry.mod.Mod;

public class Main extends Mod {
    @Override
    public void init() {
        // 设置日志级别为 ALL，确保捕获所有消息
        Log.level = Log.LogLevel.debug;
        Log.info("[purple][OrionX][red]设置日志等级为Debug");

        //初始化
        new Settings();
        Log.info("[purple][OrionX][red]初始化Settings");
        new AntiFog();
        Log.info("[purple][OrionX][red]初始化AntiFog");
        new EnableBluePrints();
        Log.info("[purple][OrionX][red]初始化EnableBluePrints");
        new AntiAFK();
        Log.info("[purple][OrionX][red]初始化AntiAFK");
        new AutoGG();
        Log.info("[purple][OrionX][red]初始化AutoGG");
        new PickHB_XEM();
        Log.info("[purple][OrionX][red]初始化PickHB_XEM");
        new AntiAFK_XEM();
        Log.info("[purple][OrionX][red]初始化AntiAFK_XEM");
        new AutoCommands_XEM();
        Log.info("[purple][OrionX][red]初始化AutoCommands_XEM");
    }
}