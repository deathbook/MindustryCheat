package OrionX;

import arc.Events;
import arc.util.Log;
import arc.util.Timer;
import mindustry.Vars;
import mindustry.game.EventType;
import mindustry.gen.Call;

public class AutoCommands_XEM {
    private static boolean enabled = false; // 标记是否启用
    private static Timer.Task task; // 保存定时任务

    public static void enable() {
        if (!enabled) {
            enabled = true;

            Events.on(EventType.WorldLoadEndEvent.class, event -> {
                task = Timer.schedule(() -> {
                    // 自动输入指令
                    Call.sendChatMessage("/mono");
                    Call.sendChatMessage("/items");
                    Call.sendChatMessage("/present");
                    Call.sendChatMessage("/vela");
                    Call.sendChatMessage("/startItems");

                    // 输出日志
                    Log.info("[purple][OrionX][red]AutoCommands_XEM 运行完毕");
                    Vars.ui.chatfrag.addMessage("[purple][OrionX][red]AutoCommands_XEM 运行完毕");
                }, 5f); // 延迟 5 秒
            });

            Log.info("[purple][OrionX][red]AutoCommands_XEM 已启用");
            Vars.ui.chatfrag.addMessage("[purple][OrionX][red]AutoCommands_XEM 已启用");
        }
    }


    public static void disable() {
        if (enabled) {
            enabled = false;
            if (task != null) {
                task.cancel();
                task = null;
            }
            Log.info("[purple][OrionX][red]AutoCommands_XEM 已禁用");
            Vars.ui.chatfrag.addMessage("[purple][OrionX][red]AutoCommands_XEM 已禁用");
        }
    }
}
