package OrionX;

import arc.Core;
import mindustry.Vars;
import mindustry.ui.dialogs.SettingsMenuDialog;

public class Settings {
    public Settings() {
        // 添加设置类别
        Vars.ui.settings.addCategory("[purple]OrionX", Core.atlas.drawable("img.png") , settingsTable -> {
            // 添加复选框设置项
            settingsTable.checkPref("[#3A006F]禁用战争迷雾", false, value -> {
                if (value) {
                    System.out.println("[purple][OrionX][red]已禁用战争迷雾");
                    AntiFog.disable();
                } else {
                    System.out.println("[purple][OrionX][red]已禁用已启用战争迷雾");
                    AntiFog.enable();
                }
            });
            settingsTable.checkPref("[#4B0091]启用反AFK检测", false, value -> {
                if (value) {
                System.out.println("[purple][OrionX][red]已启用AntiAFK");
                    AntiAFK.enable();
            } else {
                    System.out.println("[purple][OrionX][red]已禁用AntiAFK");
                    AntiAFK.disable();
            }
        });
            settingsTable.checkPref("[#5B00AE]启用蓝图", false, value -> {
                if (value) {
                    System.out.println("[purple][OrionX][red]已启用蓝图");
                    EnableBluePrints.enable();
                } else {
                    System.out.println("[purple][OrionX][red]已禁用蓝图");
                    EnableBluePrints.disable();
                }
            });
            settingsTable.checkPref("[#6F00D2]启用自动GG", false, value -> {
                if (value) {
                    System.out.println("[purple][OrionX][red]已启用AutoGG");
                    AutoGG.enable();
                } else {
                    System.out.println("[purple][OrionX][red]已禁用AutoGG");
                    AutoGG.disable();
                }
            });
            settingsTable.checkPref("[#8600FF]启用自动命令(XEM)", false, value -> {
                if (value) {
                    System.out.println("[purple][OrionX][red]已启用AutoCommands_XEM");
                    AutoCommands_XEM.enable();
                } else {
                    System.out.println("[purple][OrionX][red]已禁用AutoCommands_XEM");
                    AutoCommands_XEM.disable();
                }
            });
            settingsTable.checkPref("[#921AFF]启用自动抢红包(XEM)", false, value -> {
                if (value) {
                    System.out.println("[purple][OrionX][red]已启用PickHB_XEM");
                    PickHB_XEM.enable();
                } else {
                    System.out.println("[purple][OrionX][red]已禁用PickHB_XEM");
                    PickHB_XEM.disable();
                }
            });
            settingsTable.checkPref("[#921AFF]反AFK检测(XEM)", false, value -> {
                if (value) {
                    System.out.println("[purple][OrionX][red]已启用AntiAFK_XEM");
                    AntiAFK_XEM.enable();
                } else {
                    System.out.println("[purple][OrionX][red]已禁用AntiAFK_XEM");
                    AntiAFK_XEM.disable();
                }
            });
        });
    }
}
