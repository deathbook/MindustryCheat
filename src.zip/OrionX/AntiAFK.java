package OrionX;

import arc.util.Log;
import arc.util.Timer;
import mindustry.Vars;

public class AntiAFK {
    private static Timer.Task task;
    private static boolean enabled = false;
    public static void enable() {
        if (task == null) {
            Log.info("AntiAFK已启用");
            Vars.ui.chatfrag.addMessage("AntiAFK已启用");
            task = Timer.schedule(() -> {
                System.out.println("AntiAFK 执行了一次操作");
                Vars.ui.chatfrag.addMessage("AntiAFK 执行了一次操作");
            }, 0, 300); // 每 5 分钟执行一次
        }
    }

    public static void disable() {
        if (task != null) {
            task.cancel();
            task = null;
            System.out.println("AntiAFK 已禁用");
            Vars.ui.chatfrag.addMessage("AntiAFK 已禁用");
        }
    }
}
