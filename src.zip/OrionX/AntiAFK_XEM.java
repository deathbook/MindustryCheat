package OrionX;

import arc.Events;
import arc.util.Log;
import arc.util.Timer;
import mindustry.Vars;
import mindustry.game.EventType;
import mindustry.gen.Call;
import mindustry.ui.fragments.ChatFragment;

import java.util.TimerTask;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class AntiAFK_XEM extends ChatFragment {
    private boolean hasSended = false; // 标记是否已经发过消息，防止重复发送
    private static boolean enabled = false; // 标记功能是否启用

    public static void enable() {
        if (!enabled) {
            enabled = true;
            Vars.ui.chatfrag = new AntiAFK_XEM(); // 替换默认的 ChatFragment
            Log.info("[purple][OrionX][red]AntiAFK_XEM 已启用");
            Vars.ui.chatfrag.addMessage("[purple][OrionX][red]AntiAFK_XEM 已启用");
        }
    }

    public static void disable() {
        if (enabled) {
            enabled = false;
            Vars.ui.chatfrag = new ChatFragment(); // 恢复默认的 ChatFragment
            Log.info("[purple][OrionX][red]AntiAFK_XEM 已禁用");
            Vars.ui.chatfrag.addMessage("[purple][OrionX][red]AntiAFK_XEM 已禁用");
        }
    }

    @Override
    public void addMessage(String message) {
        // 先调用父类方法，确保消息正常显示
        if (!enabled) return; // 如果功能未启用，则不处理
        super.addMessage(message);
        // 使用正则表达式检测投票消息
        Log.info("[purple][OrionX][red]Message: " + message);
        Pattern pattern = Pattern.compile(".*使用文字投票.*");
        Matcher matcher = pattern.matcher(message);

        if (matcher.find() && !hasSended) {
            Log.info("[purple][OrionX][red]检测到投票消息");
            hasSended = true; // 设置投票标记，防止重复投票

            // 延时 3 秒后执行投票
            Timer.schedule(() -> {
                if (!enabled) return; // 如果功能被禁用，则不执行
                Log.info("[purple][OrionX][red]自动发送1");
                Vars.ui.chatfrag.addMessage("[purple][OrionX][red]自动发送1");
                Call.sendChatMessage("1");
                hasSended = false; // 重置标记，允许再次投票
            }, 3); // 延时 3 秒
        }
    }
}
