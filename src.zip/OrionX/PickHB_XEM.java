package OrionX;

import arc.util.Log;
import mindustry.Vars;
import mindustry.gen.Call;
import mindustry.ui.fragments.ChatFragment;

import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PickHB_XEM extends ChatFragment {
    private Timer timer = new Timer(); // 定义一个全局的 Timer 实例
    private boolean hasPicked = false; // 标记是否已经抢过红包，防止重复抢
    private static boolean enabled = false; // 标记功能是否启用

    public static void enable() {
        if (!enabled) {
            enabled = true;
            Vars.ui.chatfrag = new PickHB_XEM(); // 替换默认的 ChatFragment
            Log.info("[purple][OrionX][red]PickHB_XEM 已启用");
        }
    }

    public static void disable() {
        if (enabled) {
            enabled = false;
            Vars.ui.chatfrag = new ChatFragment(); // 恢复默认的 ChatFragment
            Log.info("[purple][OrionX][red]PickHB_XEM 已禁用");
        }
    }

    @Override
    public void addMessage(String message) {
        super.addMessage(message); // 调用父类方法，保持消息正常显示

        if (!enabled) return; // 如果功能未启用，则不处理

        // 使用正则表达式提取 /pickHB 指令和后面的随机字符串
        Pattern pattern = Pattern.compile("/pickHB\\s*(\\S+)");
        Matcher matcher = pattern.matcher(message);
        Log.info("检测到/pickHB消息");

        if (matcher.find() && !hasPicked) {
            String command = matcher.group(0); // 获取完整的指令
            hasPicked = true; // 设置已抢标记，防止重复抢

            // 延时 15 秒后执行抢红包命令
            timer.schedule(new TimerTask() {
                @Override
                public void run() {
                    if (!enabled) return; // 如果功能被禁用，则不执行
                    Log.info("[purple][OrionX][red]自动发送抢红包命令: " + command);
                    Vars.ui.chatfrag.addMessage("[purple][OrionX][red]自动发送抢红包命令: " + command);
                    Call.sendChatMessage(command);
                    hasPicked = false; // 重置标记，允许再次抢红包
                }
            }, 15000); // 延时 15 秒（15000 毫秒）
        }
    }
}
